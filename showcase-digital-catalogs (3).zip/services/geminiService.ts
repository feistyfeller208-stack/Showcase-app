
/**
 * Gemini AI service has been removed from the application.
 * One-tap description features are no longer active.
 */
export {};
